from jira import JIRA
import yaml

def load_config():
    with open("config.yaml") as f:
        return yaml.safe_load(f)

def connect_jira():
    config = load_config()
    return JIRA(
        server=config['jira']['server'],
        basic_auth=(config['jira']['username'], config['jira']['api_token'])
    )

def fetch_stories(jira):
    project_key = load_config()['jira']['project_key']
    issues = jira.search_issues(f'project = {project_key} AND issuetype = Story AND status != Done', maxResults=50)
    return [{
        'id': i.key,
        'summary': i.fields.summary,
        'description': i.fields.description or ""
    } for i in issues]
