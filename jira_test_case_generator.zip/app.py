import streamlit as st
import pandas as pd
from jira_utils import connect_jira, fetch_stories
from ollama_utils import generate_test_cases_ollama
import io

st.set_page_config(layout="wide", page_title="AI Test Case Generator (Offline)")

st.title("📋 AI-Powered Test Case Generator (Offline - Local LLM)")

if "jira_data" not in st.session_state:
    st.session_state.jira_data = []
if "test_cases" not in st.session_state:
    st.session_state.test_cases = pd.DataFrame()

# Step 1: Connect to JIRA
if st.button("🔄 Load JIRA Stories"):
    jira = connect_jira()
    stories = fetch_stories(jira)
    st.session_state.jira_data = stories
    st.success(f"Loaded {len(stories)} stories.")

# Step 2: Display JIRA stories
if st.session_state.jira_data:
    selected = st.selectbox("Select Story to Generate Test Cases", [f"{s['id']}: {s['summary']}" for s in st.session_state.jira_data])
    story = next(item for item in st.session_state.jira_data if item['id'] in selected)

    st.subheader("📝 User Story Description")
    st.write(story['description'])

    if st.button("🤖 Generate Test Cases using Local LLM"):
        with st.spinner("Generating test cases..."):
            output = generate_test_cases_ollama(f"{story['summary']}

{story['description']}")
            st.text_area("Generated Test Cases", value=output, height=300)

            st.session_state.test_cases = pd.DataFrame([{
                "JIRA_ID": story['id'],
                "Requirement": story['summary'],
                "Test Cases": output
            }])

# Step 3: Edit & Export
if not st.session_state.test_cases.empty:
    st.subheader("📤 Export / Edit Test Cases")
    edited_df = st.data_editor(st.session_state.test_cases, use_container_width=True, num_rows="dynamic")

    buffer = io.BytesIO()
    edited_df.to_excel(buffer, index=False)
    st.download_button("📥 Download Test Cases (Excel)", data=buffer.getvalue(), file_name="test_cases_export.xlsx")

# Step 4: Optional - Reimport to JIRA
st.markdown("#### 📥 Re-import to JIRA after manual changes (optional)")
uploaded_file = st.file_uploader("Upload modified Excel", type="xlsx")
if uploaded_file:
    df = pd.read_excel(uploaded_file)
    st.write(df)

    if st.button("🚀 Push Comments Back to JIRA"):
        jira = connect_jira()
        for _, row in df.iterrows():
            comment = f"Generated Test Cases:\n\n{row['Test Cases']}"
            jira.add_comment(row['JIRA_ID'], comment)
        st.success("Test cases pushed back as JIRA comments.")
