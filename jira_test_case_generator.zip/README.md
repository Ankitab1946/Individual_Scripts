# 🧪 AI Test Case Generator (Offline)

This is an AI-powered test case generator that works 100% offline using:
- Local LLMs via Ollama
- JIRA integration
- Streamlit UI

## ✅ Features
- Read JIRA stories
- Generate test cases using Mistral/LLaMA via Ollama
- Export to Excel
- Re-upload to JIRA after manual review

## 🧰 Requirements
- Python 3.9+
- Ollama (https://ollama.com)
- JIRA access token

## 🚀 Run
```bash
pip install -r requirements.txt
streamlit run app.py
```
