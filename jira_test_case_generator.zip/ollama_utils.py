import requests
import yaml

def load_config():
    with open("config.yaml") as f:
        return yaml.safe_load(f)

def generate_test_cases_ollama(requirement):
    config = load_config()
    prompt = f"""
You are a senior QA engineer. Write test cases for the following user story:

{requirement}

Format:
- Test Case ID
- Title
- Preconditions
- Steps
- Expected Result
"""
    response = requests.post(
        f"{config['ollama']['host']}/api/generate",
        json={"model": config['ollama']['model'], "prompt": prompt, "stream": False}
    )
    return response.json()["response"]
